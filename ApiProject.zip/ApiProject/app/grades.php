<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class grades extends Model
{
    //
}
