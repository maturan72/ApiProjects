<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\students;
use App\grades;
use App\subjects;

class ApiController extends Controller
{
    public function StudentApi()
    {
        $data = students::all();
        return response()->json($data);
    }
    
    public function GradeApi()
    {
        $data = grades::all();
        return response()->json($data);
    }

    public function SubjectApi()
    {
        $data = subjects::all();
        return response()->json($data);
    }
}
